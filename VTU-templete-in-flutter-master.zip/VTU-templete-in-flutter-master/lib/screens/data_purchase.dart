import 'package:flutter/material.dart';

class DataPurchase extends StatelessWidget {
  const DataPurchase({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  Scaffold();
  }
}
